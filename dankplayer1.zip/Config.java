public class Config {
    public static final int ROCKET_CREATION_ROUND = 300;
    public static final int ROCKET_EQUILIBRIUM = 4;
    public static final int RANGER_AUTO_ATTACK_ROUND = 100;
    public static final int ROUNDS_TO_DEVOTE_TO_FACTORIES = 30;
}
